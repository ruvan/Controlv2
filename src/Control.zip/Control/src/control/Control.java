package control;

import gnu.io.*;
import java.io.FileOutputStream; //Kept for rewriting config file
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.io.*;
import javax.sound.midi.*;

/**
 *
 * @author Ruvan Muthu-Krishna
 */
public class Control {

//  Variables which can be altered    
    Synthesizer synth;
    static Receiver[] rcvr;
    static boolean MIDI;
    static FileReader midiFile;

    /**
     * Runs initialization methods based on given args then enters infinite loop
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Control ctrl = new Control();
        //ctrl.loadConfig(args[1]);
        ctrl.loadConfig("C:\\Control\\src\\control\\config.properties", args[0]);

        if (MIDI) {
            BufferedReader reader = new BufferedReader(midiFile);
            String line = null;

            try {
                while ((line = reader.readLine()) != null) {
                    if (!line.contains("#")) {
                        System.out.println(line);
                        String[] cmd = line.split(",");
                        ShortMessage message = new ShortMessage();
                        if (cmd[0].equals("note")) {
                            // play a note
                            if (cmd[4].equals("on")) {
                                try {
                                    message.setMessage(ShortMessage.NOTE_ON, Integer.parseInt(cmd[2]), Integer.parseInt(cmd[3]), 90);
                                } catch (InvalidMidiDataException ex) {
                                }
                            } else {
                                try {
                                    message.setMessage(ShortMessage.NOTE_OFF, Integer.parseInt(cmd[2]), Integer.parseInt(cmd[3]), 90);
                                } catch (InvalidMidiDataException ex) {
                                }
                            }
                        } else if (cmd[0].equals("cc")) {
                            // send a control change command
                            try {
                                message.setMessage(ShortMessage.CONTROL_CHANGE, Integer.parseInt(cmd[2]), Integer.parseInt(cmd[3]), Integer.parseInt(cmd[4]));
                            } catch (InvalidMidiDataException ex) {
                            }
                        }
                        rcvr[Integer.parseInt(cmd[1])].send(message, 0);
                        try {
                            Thread.sleep(Long.parseLong(cmd[5]));
                        } catch (InterruptedException ex) {
                        }
                    }
                }
            } catch (IOException e) {
            }
        }

//        while (true) {
//            try {
//                ShortMessage msg = new ShortMessage();
//                msg.setMessage(ShortMessage.NOTE_ON, 0, 62, 60);
//                rcvr.send((MidiMessage) msg,0);
//            } catch (InvalidMidiDataException ex) {
//                ex.printStackTrace();
//                System.exit(1);
//            }
//            
//            // Pause for 1 second
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException ex) {
//                break;
//            }
//            
//            try {
//                ShortMessage msg = new ShortMessage();
//                msg.setMessage(ShortMessage.NOTE_OFF, 0, 62, 60);
//                rcvr.send((MidiMessage) msg,0);
//            } catch (InvalidMidiDataException ex) {
//                ex.printStackTrace();
//                System.exit(1);
//            }
//            
//             // Pause for 1 second
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException ex) {
//                break;
//            }
//        }


    }

    /**
     * Loads configuration file config.properties and assigns specified values
     * to variables once required values have been set the file is close so as
     * to not cause file lock problems.
     *
     *
     */
    public void loadConfig(String configPath, String midiFilePath) {
        Properties prop = new Properties();

        try {
            // load the properties file
            FileInputStream propertiesFile = new FileInputStream(configPath);
            prop.load(propertiesFile);

            //MIDI vars
            if (prop.getProperty("MIDI").equals("true")) {
                try {
                    initializeMidi(prop.getProperty("MIDIDevice"));
                } catch (MidiUnavailableException e) {
                }

                MIDI = true;
            } else {
                MIDI = false;
            }

            if (MIDI) {
                midiFile = new FileReader(midiFilePath);


            }



            // close the properties file
            propertiesFile.close();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void initializeMidi(String MIDIDevice) throws MidiUnavailableException {
        String[] MIDIDevices = MIDIDevice.split(",");
        if (MIDIDevices.length != 0) {
            rcvr = new Receiver[MIDIDevices.length];
        }
        MidiDevice.Info[] infos = MidiSystem.getMidiDeviceInfo();
        for (int i = 0; i < MIDIDevices.length; i++) {
            for (int j = 0; j < infos.length; j++) {
                if (MidiSystem.getMidiDevice(infos[j]).getMaxReceivers() != 0 && MidiSystem.getMidiDevice(infos[j]).getDeviceInfo().getName().contains(MIDIDevices[i])) {
                    try {
                        MidiSystem.getMidiDevice(infos[j]).open();
                        rcvr[i] = MidiSystem.getMidiDevice(infos[j]).getReceiver();
                    } catch (MidiUnavailableException e) {
                    }
                }
            }
        }
    }
    /**
     * Opens the MIDI port for transmission
     */
//    public void openMidi() {
//        try {
//            synth = MidiSystem.getSynthesizer();
//            synth.open();
//            rcvr = synth.getReceiver();
//        } catch(MidiUnavailableException ex) {
//            ex.printStackTrace();
//            System.exit(1);
//        }
//    }
}
